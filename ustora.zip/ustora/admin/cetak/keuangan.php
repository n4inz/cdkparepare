<?php 
echo $_GET['tgl'];

?>